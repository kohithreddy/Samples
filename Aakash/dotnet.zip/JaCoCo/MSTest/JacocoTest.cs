﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace JacocoReport
{
    [TestClass]
    public class JacocoTest
    {
        [TestMethod]
        public void TuetTest()
        {
            Assert.IsTrue(true);
        }
    }
}
